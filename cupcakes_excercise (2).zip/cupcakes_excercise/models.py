from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

DEFAULT_IMAGE= "https://tinyurl.com/demo-cupcake"




class Cupcake(db.Model):
    """ This is creating my database"""
    __tablename__="cupcakes"
    id= db.Column(db.Integer, autoincrement=True, primary_key=True)
    flavor= db.Column(db.Text,nullable=False)
    size= db.Column(db.Text,nullable=False)
    rating= db.Column(db.Float, nullable=False)
    image= db.Column(db.Text,nullable=False, default= DEFAULT_IMAGE)

    def show_all(self):
        """ return a dict of the cupcake"""
        return{
            "id":self.id,
            "flavor":self.flavor,
            "rating":self.rating,
            "size":self.size,
            "image":self.image,
        
        }
    

    


def connect_db(app):
    """Connect this database to Flask app"""
    db.app=app
    db.init_app(app)












