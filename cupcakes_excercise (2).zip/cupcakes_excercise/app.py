
from flask import Flask, request, jsonify, render_template
from models import connect_db, Cupcake, db



app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI']='postgresql:///cupcakes'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = "1234555533"

connect_db(app)
db.create_all()




@app.route('/')
def home():
    
    return render_template('index.html')

@app.route('/api/cupcakes')
def list_cupcakes():
    """Get data about all CupCakes"""
    """return Json"""
    """homepage"""

    all_cupcakes=[cupcakes.show_all() for cupcakes in Cupcake.query.all()]
    return jsonify(cupcakes=all_cupcakes)


@app.route('/api/cupcakes/<int:cupcake_id>')
def get_cupcakes(cupcake_id):
    
    """ Get data about a single cupcake"""
    cupcake= Cupcake.query.get_or_404(cupcake_id)

    return jsonify(cupcake=cupcake.show_all())




@app.route('/api/cupcakes', methods=['POST'])
def create_cupcake():
    
    """Create a new cupcake"""
    data = request.json
    new_cupcake= Cupcake(
        flavor=data['flavor'],
        size=data['size'],
        rating=data['rating'],
        image=data['image'] or None)

    db.session.add(new_cupcake)
    db.session.commit()

    response_json = jsonify(cupcake=new_cupcake.show_all())
    return (response_json, 201)

@app.route('/api/cupcakes/<int:cupcake_id>', methods=['PATCH'])
def update_cupcake(cupcake_id):
    """UPDATE A CUPCAKE AND RETURN JSON"""
    data = request.json
    cupcake = Cupcake.query.get_or_404(cupcake_id)
    cupcake.flavor= data['flavor']
    cupcake.rating= data['rating']
    cupcake.size= data['size']
    cupcake.image = data['image']

    db.session.add(cupcake)
    db.session.commit()
   
    return jsonify(cupcake=cupcake.show_all())

@app.route('/api/cupcakes/<int:cupcake_id>', methods=['DELETE'])
def delete(cupcake_id):
    cupcake = Cupcake.query.get_or_404(cupcake_id)

    db.session.delete(cupcake)
    db.session.commit()
    return jsonify(message="Deleted")

